#ifndef _CREATE_TCP_CLIENT_SOCKET_H_
#define _CREATE_TCP_CLIENT_SOCKET_H_

extern int CreateTCPClientSocket (const char * addr, unsigned short port); /* Create TCP server socket */

#endif
